﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DefiningClasses
{
    class Class1
    {
    }
}
