﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Problem8
{
    class Threeuple<I1,I2,I3>
    {
        public I1 item1;
        public I2 item2;
        public I3 item3;
    }
}
