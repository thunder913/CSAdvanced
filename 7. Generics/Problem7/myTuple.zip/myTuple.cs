﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Problem7
    
{
    class myTuple<F,S>
    {
        public F item1 { get; set; }
        public S item2 { get; set; }
    }
}
